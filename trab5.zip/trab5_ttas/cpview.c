#include "complex.h"

int main(int argc, char **argv){
	Complex c;
	double r, t;
	FILE *fp = fopen(argv[2], "rb");
	if(!fp){
		printf("Erro na leitura do arquivo %s!\n", argv[2]);
		exit(1);
	}
	fread(&c, sizeof(Complex), 1, fp);
	switch(argv[1][1]){
		case 'a':
			if(c.img < 0)
				printf("%.2lf%.2lfi\n", c.real, c.img);
			else
				printf("%.2lf+%.2lfi\n", c.real, c.img);
			break;
		case 'v':
			printf("[%.2lf,%.2lf]\n", c.real, c.img);
			break;
		case 'p':
			converte3(&r, &t, &c);
			printf("%.2lf;%.2lf\n", r, t);
			break;
	}
	return 0;
}
