#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#define PI 3.14159265

typedef struct{
	char code[2];
	double real;
	double img;
} Complex;

void converte1(char *s, Complex *c);

void converte2(char *s1, char *s2, Complex *c);

void converte3(double *r, double *t, Complex *c);

void sum(Complex *a, Complex *c, Complex *b);

void sub(Complex *a, Complex *c, Complex *b);

void mult(Complex *a, Complex *c, Complex *b);

void divide(Complex *a, Complex *c, Complex *b);

int acha(char c, char *s);
