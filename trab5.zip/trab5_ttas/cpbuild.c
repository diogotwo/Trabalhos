#include "complex.h"

int main(int argc, char **argv){
	FILE *fp = fopen(argv[argc-1], "w+b");
	Complex num;
	switch(argv[1][1]){
		case 'a':
		case 'v':
			converte1(argv[2], &num);
			break;
		case 'p':
			converte2(argv[2], argv[3], &num);
			break;
		}
	fwrite(&num, sizeof(Complex), 1, fp);
	return 0;
}
