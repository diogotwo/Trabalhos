#include "complex.h"

int main(int argc, char **argv){
	FILE *f1, *f2, *f3;
	Complex a, b, c;
	f1 = fopen(argv[1], "rb");
	f2 = fopen(argv[2], "rb");
	f3 = fopen(argv[3], "w+b");
	fread(&a, sizeof(Complex), 1, f1);
	fread(&b, sizeof(Complex), 1, f2);
	mult(&a, &b, &c);
	fwrite(&c, sizeof(Complex), 1, f3);
}
