#include "complex.h"

void converte1(char *s, Complex *c){
	char *delim = "+-,[]i";
	char m = s[0];
	int i = acha('-', s);
	c->real = atof(strtok(s, delim));
	if(m == '-') c->real = -c->real;
	c->img = atof(strtok(NULL, delim));
	if(i) c->img = -c->img;
	c->code[0] = 'C';
	c->code[1] = 'P';
}

void converte2(char *s1, char *s2, Complex *c){
	double a = atof(s1);
	double t = atof(s2);
	c->real = (a * cos(t * PI / 180));
	c->img = (a * sin(t * PI / 180));
	c->code[0] = 'C';
	c->code[1] = 'P';
}

void converte3(double  *r, double *t, Complex *c){
	*r = sqrt((c->real * c->real) + (c->img * c->img));
	*t = atan(c->img/c->real)*180/PI;
}

void sum(Complex *a, Complex *b, Complex *c){
	c->real = a->real + b->real;
	c->img = a->img + b->img;
	c->code[0] = 'C';
	c->code[1] = 'P';
}

void sub(Complex *a, Complex *b, Complex *c){
	c->real = a->real - b->real;
	c->img = a->img - b->img;
	c->code[0] = 'C';
	c->code[1] = 'P';
}


void mult(Complex *a, Complex *b, Complex *c){
	c->real = a->real * b->real - (a->img * b->img);
	c->img = a->real * b->img + a->img * b->real;
	c->code[0] = 'C';
	c->code[1] = 'P';
}

void divide(Complex *a, Complex *b, Complex *c){
	c->real = (a->real * b->real + a->img * b->img)/(b->real * b->real + b->img * b->img);
	c->img = (a->img * b->real - a->real * b->img)/(b->real * b->real + b->img * b->img);
	c->code[0] = 'C';
	c->code[1] = 'P';
}

int acha(char c, char *s){
	int j;
	for(j = 1; s[j] != '\0'; j++)
		if(s[j] == c) return 1;
	return 0;
}
